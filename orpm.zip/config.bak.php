<?php
	$dbServer = 'localhost';
	$dbUsername = 'root';
	$dbPassword = '';
	$dbDatabase = 'orpm';

	$adminConfig = array(
		'adminUsername' => "orpm_admin",
		'adminPassword' => "7a94abf5308fd29fc811bede50783e16",
		'notifyAdminNewMembers' => "0",
		'defaultSignUp' => "1",
		'anonymousGroup' => "anonymous",
		'anonymousMember' => "guest",
		'groupsPerPage' => "10",
		'membersPerPage' => "10",
		'recordsPerPage' => "10",
		'custom1' => "Full Name",
		'custom2' => "Address",
		'custom3' => "County",
		'custom4' => "Area",
		'MySQLDateFormat' => "%m/%d/%Y",
		'PHPDateFormat' => "n/j/Y",
		'PHPDateTimeFormat' => "m/d/Y, h:i a",
		'senderName' => "Membership management",
		'senderEmail' => "ndech90@gmail.com",
		'approvalSubject' => "Your membership is now approved",
		'approvalMessage' => "Dear member,\r\n\r\nYour membership is now approved by the admin. You can log in to your account here:\r\nhttp://localhost:8080/orpm\r\n\r\nRegards,\r\nAdmin",
		'hide_twitter_feed' => ""
	);