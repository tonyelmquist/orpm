<?php
	// For help on using hooks, please refer to http://bigprof.com/appgini/help/working-with-generated-web-database-application/hooks

	function login_ok($memberInfo, &$args){
		$username = $memberInfo['username'];
		$ip = $memberInfo['IP'];
		$date = date("Y-m-d H:i:s A");
		$details = "LOGIN";
		$session_id = session_id();

		sql("insert into audit_trail set username = '{$username}', ip = '{$ip}', ts = '{$date}', details = '{$details}'", $eo);
		return '';
	}

	/*function logout_ok($memberInfo, &$args){
		//$logout = $memberInfo['username'];
		$ip = $memberInfo['IP'];
		$logout_date = date("Y-m-d H:i:s A");
		$details = "LOGOUT";
		$session_id_now = session_id();

		sql("update audit_trail set logout_ts = '{$logout_date}', logout_details = '{$details}' WHERE session_ID = '{$session_id_now}'", $eo);
		return '';
	}
*/
	function login_failed($attempt, &$args){
		$username = $attempt['username'];
		$ip = $_SERVER['REMOTE_ADDR'];
		$ts = date("Y-m-d H:i:s A");
		$details = makeSafe("LOGIN FAILED. Username : {$attempt['username']}");
		sql("insert into audit_trail set username = '{$username}', ip = '{$ip}', ts = '{$ts}', details = '{$details}'", $eo);
	}

	function member_activity($memberInfo, $activity, &$args){
		switch($activity){
			case 'pending':
				break;

			case 'automatic':
				break;

			case 'profile':
				break;

			case 'password':
				break;

		}
	}
