<?php
$locale_arr = array (
    "language" => "English",
    "template" => array (
        "T_CHOOSE_LANGUAGE" => "Scegli la lingua",
        "T_GO" => "Andare",
        "T_LOGGED_IN_AS" => "Collegato come",
        "T_LOGIN" => "Login",
        "T_LOGOFF" => "Log Off",
        "T_ADMIN_HOME" => "Home Page Admin",
        "T_CONFIG_PROJECT" => "Configurazione del progetto",
        "T_CREATE_REPORT" => "Crea rapporto",
        "T_ENTER_PROJECT_PASSWORD" => "Immettere la password del progetto.",
		"T_ENTER_PROJECT_PASSWORD_DEMO" => "Immettere la password del progetto.<br>La password per queste esercitazioni è <b>reportico</b>",
        "T_UNABLE_TO_CONTINUE" => "Impossibile continuare",
        "T_PASSWORD_ERROR" => "Password errata. Prova di nuovo.",
        ),
        );
?>
